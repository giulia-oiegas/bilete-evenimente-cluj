<?php

// File generated from our OpenAPI spec

namespace Stripe\Util;

class ApiVersion
{
    const CURRENT = '2025-11-17.clover';
    const CURRENT_MAJOR = 'clover';
}
